# Run AWS CLI Command<a name="dp-template-runawscli"></a>

This template runs a user\-specified AWS CLI command at scheduled intervals\. 