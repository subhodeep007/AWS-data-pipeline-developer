# Databases<a name="dp-concepts-databases"></a>

AWS Data Pipeline supports the following types of databases:

[JdbcDatabase](dp-object-jdbcdatabase.md)  
A JDBC database\.

[RdsDatabase](dp-object-rdsdatabase.md)  
An Amazon RDS database\.

[RedshiftDatabase](dp-object-redshiftdatabase.md)  
An Amazon Redshift database\.