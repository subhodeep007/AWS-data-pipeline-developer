# Preconditions<a name="dp-object-preconditions"></a>

The following are the AWS Data Pipeline precondition objects:

**Topics**
+ [DynamoDBDataExists](dp-dynamodbdataexists.md)
+ [DynamoDBTableExists](dp-dynamodbtableexists.md)
+ [Exists](dp-object-exists.md)
+ [S3KeyExists](dp-object-S3KeyExists.md)
+ [S3PrefixNotEmpty](dp-object-s3prefixnotempty.md)
+ [ShellCommandPrecondition](dp-object-shellcommandprecondition.md)