# Databases<a name="dp-object-databases"></a>

The following are the AWS Data Pipeline database objects:

**Topics**
+ [JdbcDatabase](dp-object-jdbcdatabase.md)
+ [RdsDatabase](dp-object-rdsdatabase.md)
+ [RedshiftDatabase](dp-object-redshiftdatabase.md)