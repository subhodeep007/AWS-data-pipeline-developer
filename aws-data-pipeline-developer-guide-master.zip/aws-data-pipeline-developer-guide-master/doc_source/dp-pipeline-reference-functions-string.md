# String Functions<a name="dp-pipeline-reference-functions-string"></a>

 The following functions are available for working with string values\. 


****  

| Function | Description | 
| --- | --- | 
|  \+  |  Concatenation\. Non\-string values are first converted to strings\. Example: `#{"hel" + "lo"}` Result: `"hello"`  | 