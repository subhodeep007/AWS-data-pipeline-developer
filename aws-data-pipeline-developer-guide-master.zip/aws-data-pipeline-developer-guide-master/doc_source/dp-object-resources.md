# Resources<a name="dp-object-resources"></a>

The following are the AWS Data Pipeline resource objects:

**Topics**
+ [Ec2Resource](dp-object-ec2resource.md)
+ [EmrCluster](dp-object-emrcluster.md)
+ [HttpProxy](dp-object-httpproxy.md)