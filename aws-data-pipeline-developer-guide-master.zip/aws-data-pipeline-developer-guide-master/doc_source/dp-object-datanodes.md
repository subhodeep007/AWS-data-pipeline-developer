# Data Nodes<a name="dp-object-datanodes"></a>

The following are the AWS Data Pipeline data node objects:

**Topics**
+ [DynamoDBDataNode](dp-object-dynamodbdatanode.md)
+ [MySqlDataNode](dp-object-mysqldatanode.md)
+ [RedshiftDataNode](dp-object-redshiftdatanode.md)
+ [S3DataNode](dp-object-s3datanode.md)
+ [SqlDataNode](dp-object-sqldatanode.md)