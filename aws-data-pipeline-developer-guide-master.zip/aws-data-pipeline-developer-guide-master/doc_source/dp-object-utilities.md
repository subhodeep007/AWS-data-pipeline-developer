# Utilities<a name="dp-object-utilities"></a>

The following utility objects configure other pipeline objects:

**Topics**
+ [ShellScriptConfig](dp-object-shellscriptconfig.md)
+ [EmrConfiguration](dp-object-emrconfiguration.md)
+ [Property](dp-object-property.md)