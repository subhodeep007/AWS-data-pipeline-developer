# Actions<a name="dp-object-actions"></a>

The following are the AWS Data Pipeline action objects:

**Topics**
+ [SnsAlarm](dp-object-snsalarm.md)
+ [Terminate](dp-object-terminate.md)